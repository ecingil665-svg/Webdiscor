# Webdisc

Discord'dan esinlenen, mobil uyumlu gerçek zamanlı sohbet sitesi başlangıç projesi.

## Çalıştırma
1. Bilgisayarında Node.js 18 veya üstünü kur.
2. Bu klasörde terminal aç.
3. `npm install`
4. `npm start`
5. Tarayıcıda `http://localhost:3000` adresini aç.

## İnternete yayınlama
Projeyi Node.js destekleyen bir sunucuya (Render, Railway veya VPS gibi) yükleyip `npm install` ve `npm start` komutlarını çalıştır. Sesli sohbet için HTTPS gereklidir. Ücretsiz STUN sunucusu kullanılıyor; daha güvenilir bağlantı için TURN sunucusu ekle.

## Önemli sınırlar
- Bu, çalışan bir başlangıç sürümüdür; herkese açık dağıtıma hazır Discord eşdeğeri değildir.
- Sunucular ve kanallar sunucu belleğinde tutulur; sunucu yeniden başlayınca sıfırlanır.
- Kullanıcı adıyla hızlı giriş vardır; gerçek hesap, şifre, veritabanı, kalıcı arkadaş istekleri ve moderasyon henüz ekli değildir.
- Nitro ekranı yalnızca örnek arayüzdür; ödeme/abonelik yoktur.
- Gerçek ödeme, güvenlik, spam önleme, dosya yükleme ve TURN altyapısı eklemeden hassas veya büyük ölçekli kullanımda yayınlama.
